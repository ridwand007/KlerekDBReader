# Klerek DB Reader

Aplikasi Android offline untuk membuka ZIP yang berisi database SQLite (.db), menampilkan rekap transaksi, daftar struk, dan rincian item (PLU, harga, qty, diskon, subtotal).

## Membuat APK
1. Buka folder proyek ini dengan Android Studio (versi yang mendukung Android Gradle Plugin 8.7.3).
2. Tunggu Gradle Sync selesai dan pasang Android SDK Platform 35 jika diminta.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Aplikasi menggunakan pemilih dokumen Android; file ZIP diproses di perangkat dan database dibuka read-only dari cache. Tidak ada koneksi internet yang diperlukan saat aplikasi berjalan.
