package com.klerek.dbreader

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    // WARNA APLIKASI
    private val bg = Color.rgb(242, 245, 250)
    private val card = Color.WHITE
    private val blue = Color.rgb(25, 91, 180)
    private val navy = Color.rgb(17, 40, 75)
    private val darkText = Color.rgb(35, 45, 60)
    private val mutedText = Color.rgb(110, 122, 140)
    private val lineColor = Color.rgb(230, 234, 240)

    private var db: SQLiteDatabase? = null
    private var invoices = mutableListOf<Invoice>()

    private var store = "-"
    private var storeName = "-"
    private var dc = "-"
    private var user = "-"
    private var date = "-"
    private var summary = 0.0
    private var complete = false

    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var listBox: LinearLayout

    data class Invoice(
        val faktur: String,
        val total: Double,
        val discount: Double,
        val cash: Double,
        val wallet: Double,
        val card: Double,
        val change: Double,
        val time: String,
        val items: List<Item>
    )

    data class Item(
        val plu: String,
        val price: Double,
        val qty: Double,
        val disc: Double,
        val subtotal: Double
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    // =====================================
    // KOMPONEN DESAIN
    // =====================================

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun rounded(
        color: Int,
        radius: Int = 16
    ): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }
    }

    private fun txt(
        s: String,
        size: Float = 15f,
        color: Int = darkText,
        bold: Boolean = false
    ): TextView {
        return TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(5))
        }
    }

    private fun base(title: String) {

        window.statusBarColor = navy
        window.navigationBarColor = navy

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(
                dp(16),
                dp(12),
                dp(16),
                dp(24)
            )
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                dp(18),
                dp(20),
                dp(18),
                dp(20)
            )
            background = rounded(navy, 18)
        }

        header.addView(
            TextView(this).apply {
                text = title
                textSize = 25f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }
        )

        header.addView(
            TextView(this).apply {
                text = "OFFLINE DATABASE READER"
                textSize = 11f
                setTextColor(0xFFB8CBE8.toInt())
                setPadding(0, dp(5), 0, 0)
            }
        )

        root.addView(header)
        root.addView(space(16))
    }

    private fun button(
        label: String,
        action: () -> Unit
    ): Button {
        return Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(blue, 12)
            setPadding(
                dp(12),
                dp(6),
                dp(12),
                dp(6)
            )
            setOnClickListener { action() }
        }
    }

    private fun panel(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                dp(16),
                dp(16),
                dp(16),
                dp(16)
            )
            background = rounded(card, 16)
            elevation = dp(2).toFloat()
        }
    }

    private fun space(height: Int): Space {
        return Space(this).apply {
            minimumHeight = dp(height)
        }
    }

    // =====================================
    // INFORMASI TOKO SIMETRIS
    // =====================================

    private fun infoRow(
        label: String,
        value: String
    ): LinearLayout {

        return LinearLayout(this).apply {

            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL

            addView(
                txt(label, 14f, mutedText),
                LinearLayout.LayoutParams(
                    dp(95),
                    -2
                )
            )

            addView(
                txt(":", 14f, mutedText),
                LinearLayout.LayoutParams(
                    dp(12),
                    -2
                )
            )

            addView(
                txt(value, 14f, mutedText),
                LinearLayout.LayoutParams(
                    0,
                    -2,
                    1f
                )
            )
        }
    }

    // =====================================
    // HALAMAN AWAL
    // =====================================

    private fun showHome() {

        base("Klerek POS")

        val welcome = panel()

        welcome.addView(
            txt(
                "Selamat Datang",
                21f,
                navy,
                true
            )
        )

        welcome.addView(
            txt(
                "Pembaca database Klerek secara offline.",
                14f,
                mutedText
            )
        )

        welcome.addView(space(12))

        welcome.addView(
            button("PILIH FILE ZIP", ::pickZip)
        )

        welcome.addView(space(8))

        welcome.addView(
            txt(
                "Pilih file ZIP hasil unduhan Klerek. " +
                    "Database SQLite (.db) akan dibaca langsung dari dalam ZIP.",
                13f,
                mutedText
            )
        )

        root.addView(welcome)

        if (db != null) {
            renderDashboard()
        }
    }

    // =====================================
    // PEMILIHAN FILE ZIP
    // =====================================

    private fun pickZip() {

        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/zip"
            addCategory(Intent.CATEGORY_OPENABLE)
        }

        startActivityForResult(i, 10)
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (
            requestCode == 10 &&
            resultCode == RESULT_OK
        ) {
            data?.data?.let {
                loadZip(it)
            }
        }
    }

    private fun loadZip(uri: Uri) {

        try {

            val target = File(
                cacheDir,
                "klerek_import"
            ).apply {
                mkdirs()
            }

            val dbFile = File(
                target,
                "imported.db"
            )

            contentResolver.openInputStream(uri).use { input ->

                if (input == null) {
                    throw Exception("File tidak dapat dibuka")
                }

                ZipInputStream(input).use { zis ->

                    var entry = zis.nextEntry
                    var found = false

                    while (entry != null) {

                        if (
                            !entry.isDirectory &&
                            entry.name.lowercase().endsWith(".db")
                        ) {

                            dbFile.outputStream().use { out ->
                                zis.copyTo(out)
                            }

                            found = true
                            break
                        }

                        zis.closeEntry()
                        entry = zis.nextEntry
                    }

                    if (!found) {
                        throw Exception(
                            "File .db tidak ditemukan di dalam ZIP"
                        )
                    }
                }
            }

            db?.close()

            db = SQLiteDatabase.openDatabase(
                dbFile.absolutePath,
                null,
                SQLiteDatabase.OPEN_READONLY
            )

            readDatabase()
            showDashboard()

        } catch (e: Exception) {

            Toast.makeText(
                this,
                "Gagal membaca ZIP: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // =====================================
    // PEMBACAAN DATABASE
    // =====================================

    private fun hasTable(name: String): Boolean {

        return db?.rawQuery(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            arrayOf(name)
        )?.use {
            it.moveToFirst()
        } ?: false
    }

    private fun readDatabase() {

        val d = db ?: return

        if (!hasTable("tx_tsale")) {
            throw Exception(
                "Tabel transaksi tx_tsale tidak ditemukan"
            )
        }

        d.rawQuery(
            """
            SELECT
                store_id,
                date_tx,
                user_id,
                faktur,
                total_faktur,
                discount,
                promo_disc,
                cash,
                wallet,
                card,
                change_pay,
                time_tx
            FROM tx_tsale
            ORDER BY faktur
            """.trimIndent(),
            null
        ).use { c ->

            invoices.clear()

            while (c.moveToNext()) {

                val faktur = c.getString(3) ?: ""

                val bill = faktur
                    .substringAfterLast('-')
                    .takeLast(4)
                    .toIntOrNull()
                    ?.toString() ?: ""

                val items = mutableListOf<Item>()

                d.rawQuery(
                    """
                    SELECT
                        plu,
                        price,
                        qty,
                        (price*qty*COALESCE(disc,0))
                            +COALESCE(special_disc,0)
                            +COALESCE(promo_disc,0),
                        price*qty-(
                            (price*qty*COALESCE(disc,0))
                            +COALESCE(special_disc,0)
                            +COALESCE(promo_disc,0)
                        )
                    FROM tx_trans
                    WHERE store_id=?
                    AND date_tx=?
                    AND user_id=?
                    AND bill_no=?
                    ORDER BY sort_no
                    """.trimIndent(),
                    arrayOf(
                        c.getString(0),
                        c.getString(1),
                        c.getString(2),
                        bill
                    )
                ).use { x ->

                    while (x.moveToNext()) {

                        items.add(
                            Item(
                                x.getString(0) ?: "",
                                x.getDouble(1),
                                x.getDouble(2),
                                x.getDouble(3),
                                x.getDouble(4)
                            )
                        )
                    }
                }

                invoices.add(
                    Invoice(
                        faktur,
                        c.getDouble(4) - c.getDouble(5),
                        c.getDouble(5),
                        c.getDouble(7),
                        c.getDouble(8),
                        c.getDouble(9),
                        c.getDouble(10),
                        c.getString(11) ?: "",
                        items
                    )
                )

                store = c.getString(0) ?: "-"
                date = c.getString(1) ?: "-"
                user = c.getString(2) ?: "-"
            }
        }

        if (hasTable("log_app_info")) {

            d.rawQuery(
                "SELECT dc_id FROM log_app_info LIMIT 1",
                null
            ).use {
                if (it.moveToFirst()) {
                    dc = it.getString(0) ?: "-"
                }
            }
        }

        if (hasTable("tx_usi")) {

            d.rawQuery(
                """
                SELECT store_name
                FROM tx_usi
                WHERE store_id=?
                LIMIT 1
                """.trimIndent(),
                arrayOf(store)
            ).use {
                if (it.moveToFirst()) {
                    storeName = it.getString(0) ?: "-"
                }
            }
        }

        d.rawQuery(
            "SELECT COALESCE(SUM(cash-change_pay),0) FROM tx_tsale",
            null
        ).use {
            if (it.moveToFirst()) {
                summary = it.getDouble(0)
            }
        }
    }

    // =====================================
    // DASHBOARD
    // =====================================

    private fun showDashboard() {

        base("Klerek POS")

        root.addView(
            button(
                "BUKA FILE ZIP LAIN",
                ::pickZip
            )
        )

        root.addView(space(14))

        renderDashboard()
    }

    private fun renderDashboard() {

        val info = panel()

        info.addView(
            txt(
                "INFORMASI TOKO",
                13f,
                blue,
                true
            )
        )

        info.addView(
            txt(
                storeName,
                22f,
                darkText,
                true
            )
        )

        info.addView(infoRow("Kode Toko", store))
        info.addView(infoRow("DC", dc))
        info.addView(infoRow("Tanggal", date))
        info.addView(infoRow("User ID", user))

        val totalCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                dp(16),
                dp(16),
                dp(16),
                dp(16)
            )
            background = rounded(navy, 14)
        }

        totalCard.addView(
            txt(
                "TOTAL TRANSAKSI TUNAI + TOPUP FLAZZ",
                12f,
                0xFFB8CBE8.toInt(),
                true
            )
        )

        totalCard.addView(
            txt(
                rp(summary),
                27f,
                Color.WHITE,
                true
            )
        )

        info.addView(space(12))
        info.addView(totalCard)

        root.addView(info)

        root.addView(space(20))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        row.addView(
            txt(
                "Daftar Transaksi",
                20f,
                darkText,
                true
            ),
            LinearLayout.LayoutParams(
                0,
                -2,
                1f
            )
        )

        row.addView(
            button(
                if (complete) "MODE RINGKAS"
                else "MODE LENGKAP"
            ) {
                complete = !complete
                showDashboard()
            }
        )

        root.addView(row)

        search = EditText(this).apply {

            hint = "Cari nomor struk atau PLU"
            setSingleLine(true)
            textSize = 14f

            setTextColor(darkText)
            setHintTextColor(mutedText)

            setPadding(
                dp(14),
                dp(10),
                dp(14),
                dp(10)
            )

            background = rounded(Color.WHITE, 12)
        }

        val searchParams = LinearLayout.LayoutParams(
            -1,
            -2
        )

        searchParams.topMargin = dp(12)
        searchParams.bottomMargin = dp(12)

        root.addView(search, searchParams)

        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        root.addView(listBox)

        search.addTextChangedListener(
            SimpleWatcher {
                renderInvoices(it)
            }
        )

        renderInvoices("")
    }

    // =====================================
    // DAFTAR DAN DETAIL TRANSAKSI
    // =====================================

    private fun renderInvoices(q: String) {

        if (!::listBox.isInitialized) return

        listBox.removeAllViews()

        val filtered = invoices.filter {

            it.faktur.contains(q, true) ||
                it.items.any { item ->
                    item.plu.contains(q, true)
                }
        }

        if (filtered.isEmpty()) {

            val empty = panel()

            empty.addView(
                txt(
                    "Transaksi tidak ditemukan",
                    15f,
                    mutedText,
                    true
                )
            )

            listBox.addView(empty)
            return
        }

        filtered.forEach { inv ->

            val p = panel()

            val params = LinearLayout.LayoutParams(
                -1,
                -2
            )

            params.bottomMargin = dp(12)

            listBox.addView(p, params)

            val head = TextView(this).apply {

                text = "STRUK  ${inv.faktur}     ▼"
                textSize = 15f

                typeface = Typeface.DEFAULT_BOLD
                setTextColor(navy)

                setPadding(
                    0,
                    dp(8),
                    0,
                    dp(8)
                )
            }

            p.addView(head)

            p.addView(
                txt(
                    "TOTAL BELANJA",
                    11f,
                    mutedText,
                    true
                )
            )

            p.addView(
                txt(
                    rp(inv.total),
                    22f,
                    blue,
                    true
                )
            )

            val details = LinearLayout(this).apply {

                orientation = LinearLayout.VERTICAL
                visibility = View.GONE

                setPadding(
                    0,
                    dp(12),
                    0,
                    0
                )
            }

            p.addView(details)

            head.setOnClickListener {

                details.visibility =
                    if (details.visibility == View.VISIBLE) {
                        View.GONE
                    } else {
                        View.VISIBLE
                    }
            }

            details.addView(
                txt(
                    "Tanggal: $date     Jam: ${inv.time}",
                    13f,
                    mutedText
                )
            )

            addDivider(details)

            details.addView(
                txt(
                    "INFORMASI PEMBAYARAN",
                    14f,
                    blue,
                    true
                )
            )

            val payments = listOf(
                "Total" to inv.total,
                "Potongan" to inv.discount,
                "Tunai" to inv.cash,
                "Wallet" to inv.wallet,
                "Card" to inv.card,
                "Kembalian" to inv.change
            )

            // WALLET DAN CARD DISEMBUNYIKAN JIKA NOL
            payments
                .filter { (label, amount) ->
                    (label != "Wallet" && label != "Card") ||
                        amount != 0.0
                }
                .forEach { (label, amount) ->

                    val line = LinearLayout(this).apply {

                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL

                        setPadding(
                            0,
                            dp(5),
                            0,
                            dp(5)
                        )
                    }

                    line.addView(
                        txt(
                            label,
                            14f,
                            darkText
                        ),
                        LinearLayout.LayoutParams(
                            0,
                            -2,
                            1f
                        )
                    )

                    line.addView(
                        txt(
                            rp(amount),
                            14f,
                            darkText,
                            true
                        )
                    )

                    details.addView(line)
                }

            // =====================================
            // RINCIAN BARANG MODE LENGKAP
            // FORMAT SEPERTI STRUK KASIR
            // =====================================

            if (complete) {

                addDivider(details)

                details.addView(
                    txt(
                        "RINCIAN BARANG",
                        14f,
                        blue,
                        true
                    )
                )

                if (inv.items.isEmpty()) {

                    details.addView(
                        txt(
                            "Tidak ada rincian pada tx_trans.",
                            13f,
                            mutedText
                        )
                    )
                }

                inv.items.forEach { item ->

                    val itemBox = LinearLayout(this).apply {

                        orientation = LinearLayout.VERTICAL

                        setPadding(
                            0,
                            dp(8),
                            0,
                            dp(8)
                        )
                    }

                    // BARIS PLU DAN SUBTOTAL
                    val topRow = LinearLayout(this).apply {

                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }

                    topRow.addView(
                        txt(
                            item.plu,
                            13f,
                            darkText,
                            true
                        ),
                        LinearLayout.LayoutParams(
                            0,
                            -2,
                            1f
                        )
                    )

                    topRow.addView(
                        txt(
                            rp(item.subtotal),
                            14f,
                            darkText,
                            true
                        )
                    )

                    itemBox.addView(topRow)

                    // HARGA DAN QTY
                    itemBox.addView(
                        txt(
                            "${rp(item.price)} x ${fmt(item.qty)}",
                            12f,
                            mutedText
                        )
                    )

                    // POTONGAN JIKA ADA
                    if (item.disc > 0) {

                        itemBox.addView(
                            txt(
                                "Potongan: ${rp(item.disc)}",
                                12f,
                                mutedText
                            )
                        )
                    }

                    details.addView(itemBox)
                    addDivider(details)
                }

                // TOTAL AKHIR STRUK
                val totalRow = LinearLayout(this).apply {

                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL

                    setPadding(
                        0,
                        dp(10),
                        0,
                        dp(6)
                    )
                }

                totalRow.addView(
                    txt(
                        "TOTAL BELANJA",
                        14f,
                        navy,
                        true
                    ),
                    LinearLayout.LayoutParams(
                        0,
                        -2,
                        1f
                    )
                )

                totalRow.addView(
                    txt(
                        rp(inv.total),
                        16f,
                        blue,
                        true
                    )
                )

                details.addView(totalRow)
            }
        }
    }

    // =====================================
    // GARIS PEMISAH
    // =====================================

    private fun addDivider(parent: LinearLayout) {

        parent.addView(
            View(this).apply {
                setBackgroundColor(lineColor)
            },
            LinearLayout.LayoutParams(
                -1,
                dp(1)
            )
        )
    }

    // =====================================
    // FORMAT ANGKA DAN RUPIAH
    // =====================================

    private fun fmt(n: Double): String {

        return if (n % 1.0 == 0.0) {
            n.toLong().toString()
        } else {
            n.toString()
        }
    }

    private fun rp(n: Double): String {

        return "Rp" +
            String.format(
                java.util.Locale("id", "ID"),
                "%,.0f",
                n
            ).replace(',', '.')
    }
}