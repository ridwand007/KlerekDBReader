package com.klerek.dbreader

import android.app.Activity
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 12, 22)
    private val card = Color.rgb(17, 22, 34)
    private val blue = Color.rgb(40, 112, 255)
    private var db: SQLiteDatabase? = null
    private var invoices = mutableListOf<Invoice>()
    private var store = "-"; private var storeName = "-"; private var dc = "-"; private var user = "-"; private var date = "-"
    private var summary = 0.0
    private var complete = false
    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var listBox: LinearLayout

    data class Invoice(val faktur:String, val total:Double, val discount:Double, val cash:Double, val wallet:Double, val card:Double, val change:Double, val time:String, val items:List<Item>)
    data class Item(val plu:String, val price:Double, val qty:Double, val disc:Double, val subtotal:Double)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    private fun txt(s:String, size:Float=15f, color:Int=Color.WHITE, bold:Boolean=false): TextView = TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null, Typeface.BOLD); setPadding(0, dp(5), 0, dp(5))
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun base(title:String) {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(16),dp(18),dp(16),dp(18)) }
        val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll)
        val header=TextView(this).apply { text=title; textSize=26f; gravity=Gravity.CENTER; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setPadding(0,dp(10),0,dp(18)) }
        root.addView(header)
    }
    private fun button(label:String, action:()->Unit): Button = Button(this).apply { text=label; setOnClickListener { action() } }
    private fun panel(): LinearLayout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14)); setBackgroundColor(card) }
    private fun showHome() {
        base("Klerek DB Reader")
        root.addView(txt("Pembaca ZIP • SQLite • Offline",14f,0xFFB7C0D0.toInt()))
        root.addView(button("PILIH FILE ZIP", ::pickZip))
        root.addView(txt("Pilih file ZIP hasil unduhan Klerek. Database .db akan dibaca langsung dari dalam ZIP.",14f,0xFFB7C0D0.toInt()))
        if (db != null) renderDashboard()
    }
    private fun pickZip() { val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="application/zip"; addCategory(Intent.CATEGORY_OPENABLE) }; startActivityForResult(i,10) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==10 && resultCode==RESULT_OK) data?.data?.let { loadZip(it) } }
    private fun loadZip(uri:Uri) {
        try {
            val target=File(cacheDir,"klerek_import").apply { mkdirs() }
            val dbFile=File(target,"imported.db")
            contentResolver.openInputStream(uri).use { input ->
                if(input==null) throw Exception("File tidak dapat dibuka")
                ZipInputStream(input).use { zis ->
                    var entry=zis.nextEntry; var found=false
                    while(entry!=null) { if(!entry.isDirectory && entry.name.lowercase().endsWith(".db")) { dbFile.outputStream().use { out -> zis.copyTo(out) }; found=true; break }; zis.closeEntry(); entry=zis.nextEntry }
                    if(!found) throw Exception("File .db tidak ditemukan di dalam ZIP")
                }
            }
            db?.close(); db=SQLiteDatabase.openDatabase(dbFile.absolutePath,null,SQLiteDatabase.OPEN_READONLY)
            readDatabase(); showDashboard()
        } catch(e:Exception) { Toast.makeText(this,"Gagal membaca ZIP: ${e.message}",Toast.LENGTH_LONG).show() }
    }
    private fun hasTable(name:String)= db?.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(name))?.use { it.moveToFirst() } ?: false
    private fun readDatabase() {
        val d=db ?: return
        if(!hasTable("tx_tsale")) throw Exception("Tabel transaksi tx_tsale tidak ditemukan")
        d.rawQuery("SELECT store_id,date_tx,user_id,faktur,total_faktur,discount,promo_disc,cash,wallet,card,change_pay,time_tx FROM tx_tsale ORDER BY faktur",null).use { c ->
            invoices.clear()
            while(c.moveToNext()) {
                val faktur=c.getString(3) ?: ""; val bill=faktur.substringAfterLast('-').takeLast(4).toIntOrNull()?.toString() ?: ""
                val items= mutableListOf<Item>()
                d.rawQuery("SELECT plu,price,qty,(price*qty*COALESCE(disc,0))+COALESCE(special_disc,0)+COALESCE(promo_disc,0),price*qty-((price*qty*COALESCE(disc,0))+COALESCE(special_disc,0)+COALESCE(promo_disc,0)) FROM tx_trans WHERE store_id=? AND date_tx=? AND user_id=? AND bill_no=? ORDER BY sort_no", arrayOf(c.getString(0),c.getString(1),c.getString(2),bill)).use { x ->
                    while(x.moveToNext()) items.add(Item(x.getString(0),x.getDouble(1),x.getDouble(2),x.getDouble(3),x.getDouble(4)))
                }
                // Kolom discount sudah mencakup special; tambahkan promo_disc agar total potongan tidak menghitung special dua kali.
                invoices.add(Invoice(faktur,c.getDouble(4),c.getDouble(5)+c.getDouble(6),c.getDouble(7),c.getDouble(8),c.getDouble(9),c.getDouble(10),c.getString(11) ?: "",items))
                store=c.getString(0) ?: "-"; date=c.getString(1) ?: "-"; user=c.getString(2) ?: "-"
            }
        }
        if(hasTable("log_app_info")) d.rawQuery("SELECT dc_id FROM log_app_info LIMIT 1",null).use { if(it.moveToFirst()) dc=it.getString(0) ?: "-" }
        if(hasTable("tx_usi")) d.rawQuery("SELECT store_name FROM tx_usi WHERE store_id=? LIMIT 1",arrayOf(store)).use { if(it.moveToFirst()) storeName=it.getString(0) ?: "-" }
        d.rawQuery("SELECT COALESCE(SUM(cash- change_pay),0) FROM tx_tsale",null).use { if(it.moveToFirst()) summary=it.getDouble(0) }
    }
    private fun showDashboard() { base("Klerek App"); root.addView(button("BUKA FILE ZIP LAIN",::pickZip)); renderDashboard() }
    private fun renderDashboard() {
        val info=panel(); root.addView(info)
        info.addView(txt("Rekap Klerek     $dc",20f,Color.WHITE,true))
        info.addView(txt("Toko  $storeName\n\nKode Toko  $store\n\nUser ID  $user\n\nTanggal Transaksi  $date",15f,0xFFD8DCE5.toInt()))
        info.addView(txt("Total Transaksi Tunai + Topup Flazz",14f,0xFF9DA8BC.toInt()))
        info.addView(txt(rp(summary),25f,blue,true))
        root.addView(Space(this).apply { minimumHeight=dp(16) })
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        row.addView(txt("Detail Per Struk",20f,Color.WHITE,true),LinearLayout.LayoutParams(0,-2,1f))
        row.addView(button(if(complete) "MODE RINGKAS" else "MODE LENGKAP") { complete=!complete; showDashboard() })
        root.addView(row)
        search=EditText(this).apply { hint="Cari nomor struk atau PLU"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(0xFF9DA8BC.toInt()); setPadding(dp(12),dp(8),dp(12),dp(8)); setBackgroundColor(Color.WHITE) }
        root.addView(search); listBox=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }; root.addView(listBox)
        search.addTextChangedListener(SimpleWatcher { renderInvoices(it) }); renderInvoices("")
    }
    private fun renderInvoices(q:String) {
        if(!::listBox.isInitialized) return
        listBox.removeAllViews()
        invoices.filter { it.faktur.contains(q,true) || it.items.any { item -> item.plu.contains(q,true) } }.forEach { inv ->
            val p=panel(); p.setPadding(dp(14),dp(8),dp(14),dp(8)); listBox.addView(p)
            val head=TextView(this).apply { text="${inv.faktur}     ▾"; textSize=17f; setTextColor(Color.WHITE); setPadding(0,dp(12),0,dp(12)) }; p.addView(head)
            val details=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; visibility=View.GONE }; p.addView(details)
            head.setOnClickListener { details.visibility=if(details.visibility==View.VISIBLE) View.GONE else View.VISIBLE }
            details.addView(txt("Tanggal: $date     Jam: ${inv.time}\nTotal: ${rp(inv.total)}\nPotongan: ${rp(inv.discount)}\nTunai: ${rp(inv.cash)}\nWallet: ${rp(inv.wallet)}\nCard: ${rp(inv.card)}\nKembalian: ${rp(inv.change)}",14f,0xFFD8DCE5.toInt()))
            if(complete) {
                details.addView(txt("RINCIAN BARANG",15f,blue,true))
                if(inv.items.isEmpty()) details.addView(txt("Tidak ada rincian pada tx_trans.",13f,0xFFB7C0D0.toInt()))
                inv.items.forEach { item -> details.addView(txt("PLU ${item.plu}  |  Harga ${rp(item.price)}  |  Qty ${fmt(item.qty)}  |  Diskon ${rp(item.disc)}  |  Subtotal ${rp(item.subtotal)}",13f,Color.WHITE)) }
            }
        }
    }
    private fun fmt(n:Double)= if(n%1.0==0.0) n.toLong().toString() else n.toString()
    private fun rp(n:Double):String="Rp"+String.format(java.util.Locale("id","ID"),"%,.0f",n).replace(',','.')
}
